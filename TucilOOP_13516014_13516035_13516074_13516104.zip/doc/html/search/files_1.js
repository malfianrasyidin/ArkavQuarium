var searchData=
[
  ['coin_2ehpp',['Coin.hpp',['../_coin_8hpp.html',1,'']]]
];
