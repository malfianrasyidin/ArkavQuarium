var searchData=
[
  ['remove',['remove',['../class_linked_list.html#aa2d9c914f6b451adbf7f56f4c9c86a6a',1,'LinkedList']]]
];
