var searchData=
[
  ['set',['set',['../class_node.html#a73471424bb2d3e7f7790b812a21588e3',1,'Node']]],
  ['setx',['setX',['../class_aquarium_object.html#a650f8f46f51ca64889fd3e1455f9696c',1,'AquariumObject']]],
  ['sety',['setY',['../class_aquarium_object.html#aa2ee76b48d56edf3b4cc5bcd199f8efe',1,'AquariumObject']]],
  ['snail',['Snail',['../class_snail.html',1,'Snail'],['../class_snail.html#ac5501ca7ead01b2ba0b7286503599f68',1,'Snail::Snail()']]],
  ['snail_2ehpp',['Snail.hpp',['../_snail_8hpp.html',1,'']]]
];
